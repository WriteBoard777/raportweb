@pure

<div {{ $attributes->class('text-sm') }} data-slot="text">
    {{ $slot }}
</div>
