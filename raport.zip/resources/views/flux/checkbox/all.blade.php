
<flux:checkbox all :$attributes />
