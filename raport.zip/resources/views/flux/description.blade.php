@pure

<ui-description {{ $attributes->class('text-sm text-zinc-500 dark:text-white/60') }} data-flux-description>
    {{ $slot }}
</ui-description>
