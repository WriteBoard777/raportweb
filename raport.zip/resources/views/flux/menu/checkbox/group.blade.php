@pure

<ui-menu-checkbox-group {{ $attributes }} data-flux-menu-checkbox-group>
    {{ $slot }}
</ui-menu-checkbox-group>
