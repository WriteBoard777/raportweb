@pure

<div {{ $attributes->class('flex items-center justify-between gap-2 min-h-10') }} data-flux-sidebar-header>
    {{ $slot }}
</div>